// Language types
export type Language = 'en' | 'es' | 'fr' | 'de' | 'zh' | 'ja' | 'ko' | 'ar' | 'hi';

// Token provider types
export type TokenProvider = 'openai' | 'claude' | 'deepseek' | 'gemini';

// Token information
export interface TokenInfo {
  count: number;
  provider: TokenProvider;
}

// Theme types
export type ColorTheme = 'blue' | 'purple' | 'green' | 'orange' | 'pink';

// Conversion modes
export type ConversionMode = 'json-to-toon' | 'toon-to-json';

// View modes for editor
export type ViewMode = 'text' | 'tree' | 'table';

// TOON conversion configuration
export interface ToonConfig {
  compress?: boolean;
  preserveTypes?: boolean;
  sortKeys?: boolean;
}

// Editor state
export interface EditorState {
  input: string;
  output: string;
  mode: ConversionMode;
  leftViewMode: ViewMode;
  rightViewMode: ViewMode;
  isProcessing: boolean;
  error: string | null;
  inputTokens: number;
  outputTokens: number;
}

// File upload types
export interface FileUploadProps {
  accept?: string;
  onFileRead: (content: string, filename: string) => void;
  className?: string;
  children: React.ReactNode;
}

// Search functionality
export interface SearchOptions {
  caseSensitive?: boolean;
  wholeWord?: boolean;
  regex?: boolean;
}

// Translation structure
export interface TranslationKeys {
  nav: {
    jsonToToon: string;
    toon: string;
    features: string;
    api: string;
    contact: string;
  };
  editor: {
    jsonInput: string;
    toonOutput: string;
    convert: string;
    reverse: string;
    copy: string;
    clear: string;
    upload: string;
    download: string;
    sample: string;
    tokens: string;
    search: string;
    textView: string;
    treeView: string;
    tableView: string;
  };
  common: {
    loading: string;
    error: string;
    success: string;
    online: string;
    offline: string;
  };
}

// API response types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Contact form
export interface ContactFormData {
  name: string;
  email: string;
  description: string;
}

// Analytics events
export interface AnalyticsEvent {
  event: string;
  category: string;
  action: string;
  label?: string;
  value?: number;
}

// Token savings tracking
export interface TokenSavings {
  originalTokens: number;
  convertedTokens: number;
  savings: number;
  percentage: number;
  timestamp: number;
}

// localStorage keys
export const STORAGE_KEYS = {
  LANGUAGE: 'toonlint-language',
  COLOR_THEME: 'toonlint-color-theme',
  DARK_MODE: 'toonlint-dark-mode',
  TOKEN_SAVINGS: 'toonlint-token-savings',
  LAST_INPUT: 'toonlint-last-input',
  PREFERENCES: 'toonlint-preferences',
} as const;

// Component props types
export interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
  colorTheme: ColorTheme;
  setColorTheme: (theme: ColorTheme) => void;
}

export interface MainEditorProps {
  language: Language;
}

// Error types
export class ToonError extends Error {
  constructor(message: string, public code?: string) {
    super(message);
    this.name = 'ToonError';
  }
}

export class ValidationError extends ToonError {
  constructor(message: string) {
    super(message, 'VALIDATION_ERROR');
    this.name = 'ValidationError';
  }
}

export class ConversionError extends ToonError {
  constructor(message: string) {
    super(message, 'CONVERSION_ERROR');
    this.name = 'ConversionError';
  }
}
