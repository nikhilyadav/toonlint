'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ChevronDown, Moon, Sun, Globe, Palette } from 'lucide-react';
import { Language } from '@/types';
import { getTranslation } from '@/lib/translations';

interface NavbarProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
  colorTheme: string;
  setColorTheme: (theme: string) => void;
}

const colorThemes = {
  blue: { name: 'Ocean Blue', color: '#3B82F6' },
  purple: { name: 'Royal Purple', color: '#8B5CF6' },
  green: { name: 'Forest Green', color: '#10B981' },
  orange: { name: 'Sunset Orange', color: '#F97316' },
  pink: { name: 'Cherry Pink', color: '#EC4899' }
};

export function Navbar({ language, setLanguage, isDark, setIsDark, colorTheme, setColorTheme }: NavbarProps) {
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  
  const t = getTranslation(language);

  const languages = [
    { code: 'en' as Language, name: 'English', flag: '🇺🇸' },
    { code: 'es' as Language, name: 'Español', flag: '🇪🇸' },
    { code: 'fr' as Language, name: 'Français', flag: '🇫🇷' },
    { code: 'de' as Language, name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh' as Language, name: '中文', flag: '🇨🇳' },
    { code: 'ja' as Language, name: '日本語', flag: '🇯🇵' },
    { code: 'ko' as Language, name: '한국어', flag: '🇰🇷' },
    { code: 'ar' as Language, name: 'العربية', flag: '🇸🇦' },
    { code: 'hi' as Language, name: 'हिंदी', flag: '🇮🇳' },
  ];

  const currentLang = languages.find(l => l.code === language) || languages[0];

  return (
    <nav className="bg-white/95 backdrop-blur-sm shadow-lg border-b border-gray-200 sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Left side - Logo and Navigation */}
          <div className="flex items-center space-x-8">
            <Link href="/" className="text-2xl font-bold text-gray-800 hover:text-blue-600 transition-colors">
              ToonLint
            </Link>
            
            <div className="hidden md:flex items-center space-x-6">
              <Link 
                href="/" 
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t.nav.jsonToToon}
              </Link>
              <Link 
                href="/toon" 
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t.nav.toon}
              </Link>
              <Link 
                href="/features" 
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t.nav.features}
              </Link>
              <Link 
                href="/api" 
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t.nav.api}
              </Link>
              <Link 
                href="/contact" 
                className="text-gray-600 hover:text-blue-600 transition-colors font-medium"
              >
                {t.nav.contact}
              </Link>
            </div>
          </div>

          {/* Right side - Controls */}
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => {
                  setIsLanguageOpen(!isLanguageOpen);
                  setIsPaletteOpen(false);
                }}
                className="flex items-center space-x-2 px-3 py-2 bg-white text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
              >
                <Globe className="h-4 w-4" />
                <span className="text-sm font-medium">{currentLang.flag} {currentLang.name}</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              {isLanguageOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-300 rounded-lg shadow-xl z-50 max-h-64 overflow-y-auto">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setIsLanguageOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors flex items-center space-x-2 text-sm"
                    >
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                      {lang.code === language && <span className="ml-auto text-blue-600">✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Color Theme Selector */}
            <div className="relative">
              <button
                onClick={() => {
                  setIsPaletteOpen(!isPaletteOpen);
                  setIsLanguageOpen(false);
                }}
                className="flex items-center space-x-2 px-3 py-2 bg-white text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
              >
                <Palette className="h-4 w-4" />
                <div 
                  className="w-4 h-4 rounded-full border border-gray-300" 
                  style={{ backgroundColor: colorThemes[colorTheme as keyof typeof colorThemes]?.color || '#3B82F6' }}
                ></div>
                <ChevronDown className="h-4 w-4" />
              </button>

              {isPaletteOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-300 rounded-lg shadow-xl z-50">
                  <div className="p-2">
                    <div className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-2 px-2">
                      Choose Theme
                    </div>
                    {Object.entries(colorThemes).map(([key, theme]) => (
                      <button
                        key={key}
                        onClick={() => {
                          setColorTheme(key);
                          setIsPaletteOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-gray-100 transition-colors flex items-center space-x-3 text-sm rounded-md"
                      >
                        <div 
                          className="w-5 h-5 rounded-full border border-gray-300" 
                          style={{ backgroundColor: theme.color }}
                        ></div>
                        <span>{theme.name}</span>
                        {key === colorTheme && <span className="ml-auto text-blue-600">✓</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Dark/Light Mode Toggle */}
            <button
              onClick={() => setIsDark(!isDark)}
              className="flex items-center justify-center w-10 h-10 bg-white text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
            >
              {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            {/* Online/Offline Status */}
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-gray-600 hidden sm:block">Online</span>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className="md:hidden border-t border-gray-200">
        <div className="px-4 py-2 space-y-1">
          <Link href="/" className="block px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors">
            {t.nav.jsonToToon}
          </Link>
          <Link href="/toon" className="block px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors">
            {t.nav.toon}
          </Link>
          <Link href="/features" className="block px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors">
            {t.nav.features}
          </Link>
          <Link href="/api" className="block px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors">
            {t.nav.api}
          </Link>
          <Link href="/contact" className="block px-3 py-2 text-gray-600 hover:text-blue-600 transition-colors">
            {t.nav.contact}
          </Link>
        </div>
      </div>

      {/* Click outside to close dropdowns */}
      {(isLanguageOpen || isPaletteOpen) && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => {
            setIsLanguageOpen(false);
            setIsPaletteOpen(false);
          }}
        ></div>
      )}
    </nav>
  );
}
