'use client';

import React, { useState, useEffect } from 'react';
import { ArrowRight, ArrowLeft, Upload, Download, FileText, Copy, RotateCcw, Search, FileType, Grid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { convertToToon, convertFromToon } from '@/lib/toon-converter';
import { countTokens } from '@/lib/token-counter';
import { Language } from '@/types';
import { getTranslation } from '@/lib/translations';

interface MainEditorProps {
  language: Language;
}

type ConversionMode = 'json-to-toon' | 'toon-to-json';
type ViewMode = 'text' | 'tree' | 'table';

export function MainEditor({ language }: MainEditorProps) {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [mode, setMode] = useState<ConversionMode>('json-to-toon');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [inputTokens, setInputTokens] = useState(0);
  const [outputTokens, setOutputTokens] = useState(0);
  const [leftViewMode, setLeftViewMode] = useState<ViewMode>('text');
  const [rightViewMode, setRightViewMode] = useState<ViewMode>('text');
  const [searchLeft, setSearchLeft] = useState('');
  const [searchRight, setSearchRight] = useState('');
  
  const t = getTranslation(language);

  const sampleData = {
    "name": "ToonLint",
    "version": "2.0.0", 
    "description": "Advanced JSON to TOON bidirectional converter",
    "features": ["Bidirectional transformation", "Token counting", "Beautiful design", "Multiple themes"],
    "stats": {
      "conversions": 1247,
      "tokensSaved": 45892,
      "users": 856
    },
    "active": true
  };

  useEffect(() => {
    if (input) {
      const tokens = countTokens(input);
      setInputTokens(tokens);
    } else {
      setInputTokens(0);
    }
  }, [input]);

  useEffect(() => {
    if (output) {
      const tokens = countTokens(output);
      setOutputTokens(tokens);
    } else {
      setOutputTokens(0);
    }
  }, [output]);

  const handleConvert = async () => {
    if (!input.trim()) {
      setError('Please enter some content to convert.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate processing
      
      if (mode === 'json-to-toon') {
        const result = convertToToon(input);
        setOutput(result);
      } else {
        const result = convertFromToon(input);
        setOutput(JSON.stringify(result, null, 2));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Conversion failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReverse = async () => {
    if (!output.trim()) {
      setError('No output to reverse.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      if (mode === 'json-to-toon') {
        const result = convertFromToon(output);
        setInput(JSON.stringify(result, null, 2));
      } else {
        const result = convertToToon(output);
        setInput(result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Reverse conversion failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSwapMode = () => {
    setMode(mode === 'json-to-toon' ? 'toon-to-json' : 'json-to-toon');
    // Swap input and output
    const temp = input;
    setInput(output);
    setOutput(temp);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, target: 'input' | 'output') => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (target === 'input') {
        setInput(content);
      } else {
        setOutput(content);
      }
    };
    reader.readAsText(file);
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  const handleClear = (target: 'input' | 'output') => {
    if (target === 'input') {
      setInput('');
    } else {
      setOutput('');
    }
  };

  const handleLoadSample = () => {
    setInput(JSON.stringify(sampleData, null, 2));
  };

  const tokenSavings = inputTokens > outputTokens ? inputTokens - outputTokens : 0;
  const savingsPercentage = inputTokens > 0 ? Math.round((tokenSavings / inputTokens) * 100) : 0;

  return (
    <div className="container mx-auto px-4 py-8">
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {/* Token Savings Display */}
      {tokenSavings > 0 && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="text-green-700 font-medium">
              🎉 Token Savings: {tokenSavings} tokens ({savingsPercentage}% reduction)
            </div>
            <div className="text-sm text-green-600">
              Original: {inputTokens} → Converted: {outputTokens}
            </div>
          </div>
        </div>
      )}

      {/* Mode Switcher */}
      <div className="mb-6 flex justify-center">
        <Button
          onClick={handleSwapMode}
          variant="outline"
          className="flex items-center space-x-2"
        >
          <RotateCcw className="h-4 w-4" />
          <span>{mode === 'json-to-toon' ? 'Switch to TOON → JSON' : 'Switch to JSON → TOON'}</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Panel */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
                {mode === 'json-to-toon' ? 'JSON Input' : 'TOON Input'}
              </h3>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={handleLoadSample}
                  variant="outline"
                  size="sm"
                  className="text-xs"
                >
                  Sample
                </Button>
                <Button
                  onClick={() => handleClear('input')}
                  variant="outline"
                  size="sm"
                  className="text-xs"
                >
                  Clear
                </Button>
              </div>
            </div>
            
            {/* View Mode Selector */}
            <div className="flex items-center space-x-2 mb-3">
              <Button
                variant={leftViewMode === 'text' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLeftViewMode('text')}
                className="text-xs"
              >
                <FileType className="h-3 w-3 mr-1" />
                Text
              </Button>
              <Button
                variant={leftViewMode === 'tree' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLeftViewMode('tree')}
                className="text-xs"
              >
                <FileText className="h-3 w-3 mr-1" />
                Tree
              </Button>
              <Button
                variant={leftViewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLeftViewMode('table')}
                className="text-xs"
              >
                <Grid className="h-3 w-3 mr-1" />
                Table
              </Button>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search in content..."
                value={searchLeft}
                onChange={(e) => setSearchLeft(e.target.value)}
                className="w-full pl-10 pr-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              />
            </div>
          </div>

          <div className="p-6">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={mode === 'json-to-toon' ? 'Paste your JSON here...' : 'Paste your TOON here...'}
              className="min-h-[400px] w-full p-4 text-sm font-mono border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            />
            
            {/* File Upload */}
            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <input
                  type="file"
                  accept=".json,.txt"
                  onChange={(e) => handleFileUpload(e, 'input')}
                  className="hidden"
                  id="input-file"
                />
                <label htmlFor="input-file" className="cursor-pointer">
                  <Button variant="outline" size="sm" asChild>
                    <span>
                      <Upload className="h-4 w-4 mr-2" />
                      Upload File
                    </span>
                  </Button>
                </label>
                <Button
                  onClick={() => handleCopy(input)}
                  variant="outline"
                  size="sm"
                  disabled={!input}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
              </div>
              <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-200">
                {inputTokens} tokens
              </div>
            </div>
          </div>
        </div>

        {/* Center Controls */}
        <div className="lg:hidden flex justify-center py-4">
          <div className="flex flex-col space-y-2">
            <Button
              onClick={handleConvert}
              disabled={isProcessing || !input.trim()}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
            >
              {isProcessing ? (
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2" />
              ) : (
                <ArrowRight className="h-4 w-4 mr-2" />
              )}
              Convert
            </Button>
            <Button
              onClick={handleReverse}
              disabled={isProcessing || !output.trim()}
              variant="outline"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Reverse
            </Button>
          </div>
        </div>

        {/* Right Panel */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-green-50 to-emerald-50">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-800">
                {mode === 'json-to-toon' ? 'TOON Output' : 'JSON Output'}
              </h3>
              <div className="hidden lg:flex items-center space-x-2">
                <Button
                  onClick={handleConvert}
                  disabled={isProcessing || !input.trim()}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  size="sm"
                >
                  {isProcessing ? (
                    <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                  ) : (
                    <ArrowRight className="h-4 w-4 mr-2" />
                  )}
                  Convert
                </Button>
                <Button
                  onClick={handleReverse}
                  disabled={isProcessing || !output.trim()}
                  variant="outline"
                  size="sm"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Reverse
                </Button>
              </div>
            </div>
            
            {/* View Mode Selector */}
            <div className="flex items-center space-x-2 mb-3">
              <Button
                variant={rightViewMode === 'text' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRightViewMode('text')}
                className="text-xs"
              >
                <FileType className="h-3 w-3 mr-1" />
                Text
              </Button>
              <Button
                variant={rightViewMode === 'tree' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRightViewMode('tree')}
                className="text-xs"
              >
                <FileText className="h-3 w-3 mr-1" />
                Tree
              </Button>
              <Button
                variant={rightViewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setRightViewMode('table')}
                className="text-xs"
              >
                <Grid className="h-3 w-3 mr-1" />
                Table
              </Button>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search in content..."
                value={searchRight}
                onChange={(e) => setSearchRight(e.target.value)}
                className="w-full pl-10 pr-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
              />
            </div>
          </div>

          <div className="p-6">
            <Textarea
              value={output}
              onChange={(e) => setOutput(e.target.value)}
              placeholder="Converted output will appear here..."
              className="min-h-[400px] w-full p-4 text-sm font-mono border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
              readOnly
            />
            
            <div className="mt-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => handleCopy(output)}
                  variant="outline"
                  size="sm"
                  disabled={!output}
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </Button>
                <Button
                  onClick={() => {
                    const blob = new Blob([output], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `converted.${mode === 'json-to-toon' ? 'toon' : 'json'}`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  variant="outline"
                  size="sm"
                  disabled={!output}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
              <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600 border border-gray-200">
                {outputTokens} tokens
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
