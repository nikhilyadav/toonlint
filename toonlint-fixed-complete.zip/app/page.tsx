'use client';

import { useState, useEffect } from 'react';
import { Navbar } from '@/components/navbar';
import { MainEditor } from '@/components/main-editor';
import { Language } from '@/types';

export default function HomePage() {
  const [language, setLanguage] = useState<Language>('en');
  const [isDark, setIsDark] = useState(false);
  const [colorTheme, setColorTheme] = useState('blue');

  // Load saved preferences
  useEffect(() => {
    const savedLang = localStorage.getItem('toonlint-language') as Language;
    const savedTheme = localStorage.getItem('toonlint-color-theme');
    const savedDark = localStorage.getItem('toonlint-dark-mode') === 'true';

    if (savedLang) setLanguage(savedLang);
    if (savedTheme) setColorTheme(savedTheme);
    setIsDark(savedDark);
  }, []);

  // Save preferences
  useEffect(() => {
    localStorage.setItem('toonlint-language', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('toonlint-color-theme', colorTheme);
  }, [colorTheme]);

  useEffect(() => {
    localStorage.setItem('toonlint-dark-mode', isDark.toString());
  }, [isDark]);

  // Apply theme classes
  useEffect(() => {
    const root = document.documentElement;
    
    // Remove old theme classes
    root.classList.remove('theme-blue', 'theme-purple', 'theme-green', 'theme-orange', 'theme-pink');
    root.classList.remove('dark', 'light');
    
    // Apply new theme
    root.classList.add(`theme-${colorTheme}`);
    root.classList.add(isDark ? 'dark' : 'light');
  }, [colorTheme, isDark]);

  return (
    <div className="min-h-screen">
      <Navbar
        language={language}
        setLanguage={setLanguage}
        isDark={isDark}
        setIsDark={setIsDark}
        colorTheme={colorTheme}
        setColorTheme={setColorTheme}
      />
      <MainEditor language={language} />
    </div>
  );
}
