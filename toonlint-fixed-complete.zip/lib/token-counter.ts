// Simple token estimation function for different AI providers
export function countTokens(text: string): number {
  if (!text) return 0;
  
  // Rough estimation: average 4 characters per token
  // Account for JSON structure overhead
  const baseTokens = Math.ceil(text.length / 4);
  
  // Add penalty for JSON structure (brackets, quotes, commas)
  const structureChars = (text.match(/[{}[\],":]/g) || []).length;
  const structureTokens = Math.ceil(structureChars / 2);
  
  return baseTokens + structureTokens;
}

export class TokenCounter {
  // Calculate token savings
  static calculateSavings(originalTokens: number, convertedTokens: number): number {
    return Math.max(0, originalTokens - convertedTokens);
  }

  // Get savings percentage
  static getSavingsPercentage(originalTokens: number, convertedTokens: number): number {
    if (originalTokens === 0) return 0;
    const savings = this.calculateSavings(originalTokens, convertedTokens);
    return Math.round((savings / originalTokens) * 100);
  }

  // Format token count for display
  static formatTokenCount(count: number): string {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  }
}
