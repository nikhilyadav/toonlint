// TOON (Text Object Oriented Notation) Converter
// A simplified, more efficient format for representing JSON-like data

export interface ToonConfig {
  compress?: boolean;
  preserveTypes?: boolean;
  sortKeys?: boolean;
}

export class ToonConverter {
  // Convert JSON to TOON format
  static encodeToToon(data: any, config: ToonConfig = {}): string {
    const { compress = true, preserveTypes = true, sortKeys = false } = config;
    
    return this._encode(data, compress, preserveTypes, sortKeys);
  }

  // Convert TOON format back to JSON
  static decodeFromToon(toonString: string): any {
    try {
      return this._decode(toonString.trim());
    } catch (error) {
      throw new Error(`Failed to decode TOON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private static _encode(obj: any, compress: boolean, preserveTypes: boolean, sortKeys: boolean): string {
    if (obj === null) return 'null';
    if (obj === undefined) return 'undefined';
    
    const type = typeof obj;
    
    switch (type) {
      case 'boolean':
        return obj ? 'true' : 'false';
      
      case 'number':
        return obj.toString();
      
      case 'string':
        // Escape special characters
        const escaped = obj
          .replace(/\\/g, '\\\\')
          .replace(/"/g, '\\"')
          .replace(/\n/g, '\\n')
          .replace(/\r/g, '\\r')
          .replace(/\t/g, '\\t');
        return `"${escaped}"`;
      
      case 'object':
        if (Array.isArray(obj)) {
          const items = obj.map(item => this._encode(item, compress, preserveTypes, sortKeys));
          const separator = compress ? ',' : ', ';
          return `[${items.join(separator)}]`;
        }
        
        if (obj === null) return 'null';
        
        // Handle regular objects
        let keys = Object.keys(obj);
        if (sortKeys) {
          keys = keys.sort();
        }
        
        const pairs = keys.map(key => {
          const value = this._encode(obj[key], compress, preserveTypes, sortKeys);
          const escapedKey = key.includes(' ') || key.includes('"') ? `"${key}"` : key;
          return `${escapedKey}:${compress ? '' : ' '}${value}`;
        });
        
        const separator = compress ? ',' : ', ';
        const spacing = compress ? '' : ' ';
        return `{${spacing}${pairs.join(separator)}${spacing}}`;
      
      default:
        return `"${String(obj)}"`;
    }
  }

  private static _decode(str: string): any {
    str = str.trim();
    
    if (str === 'null') return null;
    if (str === 'undefined') return undefined;
    if (str === 'true') return true;
    if (str === 'false') return false;
    
    // Number
    if (/^-?\d+(\.\d+)?([eE][+-]?\d+)?$/.test(str)) {
      return parseFloat(str);
    }
    
    // String
    if (str.startsWith('"') && str.endsWith('"')) {
      return str
        .slice(1, -1)
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, '\\')
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '\r')
        .replace(/\\t/g, '\t');
    }
    
    // Array
    if (str.startsWith('[') && str.endsWith(']')) {
      const content = str.slice(1, -1).trim();
      if (!content) return [];
      
      const items = this._parseArrayItems(content);
      return items.map(item => this._decode(item));
    }
    
    // Object
    if (str.startsWith('{') && str.endsWith('}')) {
      const content = str.slice(1, -1).trim();
      if (!content) return {};
      
      const pairs = this._parseObjectPairs(content);
      const result: any = {};
      
      pairs.forEach(pair => {
        const colonIndex = pair.indexOf(':');
        if (colonIndex === -1) throw new Error('Invalid object pair');
        
        let key = pair.substring(0, colonIndex).trim();
        const value = pair.substring(colonIndex + 1).trim();
        
        // Remove quotes from key if present
        if (key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1);
        }
        
        result[key] = this._decode(value);
      });
      
      return result;
    }
    
    throw new Error(`Cannot parse TOON value: ${str}`);
  }

  private static _parseArrayItems(content: string): string[] {
    const items: string[] = [];
    let current = '';
    let depth = 0;
    let inString = false;
    let escapeNext = false;
    
    for (let i = 0; i < content.length; i++) {
      const char = content[i];
      
      if (escapeNext) {
        current += char;
        escapeNext = false;
        continue;
      }
      
      if (char === '\\') {
        escapeNext = true;
        current += char;
        continue;
      }
      
      if (char === '"') {
        inString = !inString;
        current += char;
        continue;
      }
      
      if (!inString) {
        if (char === '[' || char === '{') {
          depth++;
        } else if (char === ']' || char === '}') {
          depth--;
        } else if (char === ',' && depth === 0) {
          items.push(current.trim());
          current = '';
          continue;
        }
      }
      
      current += char;
    }
    
    if (current.trim()) {
      items.push(current.trim());
    }
    
    return items;
  }

  private static _parseObjectPairs(content: string): string[] {
    const pairs: string[] = [];
    let current = '';
    let depth = 0;
    let inString = false;
    let escapeNext = false;
    
    for (let i = 0; i < content.length; i++) {
      const char = content[i];
      
      if (escapeNext) {
        current += char;
        escapeNext = false;
        continue;
      }
      
      if (char === '\\') {
        escapeNext = true;
        current += char;
        continue;
      }
      
      if (char === '"') {
        inString = !inString;
        current += char;
        continue;
      }
      
      if (!inString) {
        if (char === '[' || char === '{') {
          depth++;
        } else if (char === ']' || char === '}') {
          depth--;
        } else if (char === ',' && depth === 0) {
          pairs.push(current.trim());
          current = '';
          continue;
        }
      }
      
      current += char;
    }
    
    if (current.trim()) {
      pairs.push(current.trim());
    }
    
    return pairs;
  }

  // Validate JSON format
  static validateJson(jsonString: string): { isValid: boolean; error?: string } {
    try {
      JSON.parse(jsonString);
      return { isValid: true };
    } catch (error) {
      return {
        isValid: false,
        error: error instanceof Error ? error.message : 'Invalid JSON format'
      };
    }
  }

  // Validate TOON format
  static validateToon(toonString: string): { isValid: boolean; error?: string } {
    try {
      this.decodeFromToon(toonString);
      return { isValid: true };
    } catch (error) {
      return {
        isValid: false,
        error: error instanceof Error ? error.message : 'Invalid TOON format'
      };
    }
  }

  // Format JSON with proper indentation
  static formatJson(jsonString: string): string {
    try {
      const parsed = JSON.parse(jsonString);
      return JSON.stringify(parsed, null, 2);
    } catch (error) {
      throw new Error('Cannot format invalid JSON');
    }
  }

  // Format TOON (basic formatting)
  static formatToon(toonString: string): string {
    try {
      const parsed = this.decodeFromToon(toonString);
      return this.encodeToToon(parsed, { compress: false });
    } catch (error) {
      throw new Error('Cannot format invalid TOON');
    }
  }
}

// Convenience functions for external use
export function convertToToon(jsonString: string): string {
  const parsed = JSON.parse(jsonString);
  return ToonConverter.encodeToToon(parsed);
}

export function convertFromToon(toonString: string): any {
  return ToonConverter.decodeFromToon(toonString);
}
